<?php
session_start();
?>

<div class="article">
	<h1>Личный кабинет</h1>
	<div class="chapter">
		<hr>
<?php
	if ($session_check == 1){ //При разрешающем флаге авторизации
		$table = 'orders';
		$column = 'client-login';
		$value = $_SESSION['login'];
		if ($data_bd = getLine($table, $column, $value)) {
			$client_name = $data_bd["client-name"];
			$client_email = $data_bd["client-email"];
		}
?>
			<div class="input9">
				<div>Имя:</div>
				<div><?php echo $client_name; ?></div>
			</div>
			<div class="input9">
				<div>Логин:</div>
				<div><?php echo $_SESSION['login']; ?></div>
			</div>	
			<div class="input9">
				<div>e-mail:</div>
				<div><?php echo $client_email; ?></div>
			</div>
			<div class="input12">
				<div>Пароль:</div>
				<div>&bull;&bull;&bull;&bull;&bull;&bull;&bull;</div>
			</div>
			
		</div>
<?php
	}
	else{
?>
		<p>Личный кабинет доступен только для авторизованных пользователей. Для входа в него необходимо авторизоваться на сайте со своим логином и паролем в соответствующей форме.</p> 
<?php
	}
?>
</div>
