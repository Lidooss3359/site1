<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

<header>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <nav class="nav">
                    <a class="nav-link active" aria-current="page" target="_blank" href="index.php">Главная</a>
                    <a class="nav-link" target="_blank" href="login.php">Авторизация</a>
                    <a class="nav-link" target="_blank" href="register.php">Регистрация</a>
                    <a class="nav-link" target="_blank" href="kabinet.php">Личный кабинет</a>
                </nav>
            </div>
        </div>
    </div>
  </header>
