<?php
    session_start();
?>

<html>
    <head>
        <title>Регистрация</title>
    </head>
    <body>
        <div align="center">
        <h2>Регистрация</h2>
        <form action="functions/save_user.php" method="post">

        <p>
            <label>Ваш логин:<br></label>
            <input name="login" type="text" size="15" maxlength="15">
        </p>

        <p>
            <label>Ваша почта:<br></label>
            <input name="email" type="email" size="15" maxlength="30">
        </p>
        <p>
            <label>Ваш пароль:<br></label>
            <input name="password" type="password" size="15" maxlength="15">
        </p>

        <p>
            <input type="submit" name="submit" value="Зарегистрироваться">
 
        </p>
    </form>
    </div>
    </body>
</html>